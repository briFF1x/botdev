const Discord = require('discord.js')

module.exports = {
    run: message => {
        const member = message.mentions.members.first()
        if (!member) return message.channel.send('Veuillez mentionner le membre à With list.')
        message.channel.send(new Discord.MessageEmbed()
            .setTitle('**WL Acceptée**')
            .setDescription(`${member} Tu as réussi ta candidature ! 

            Pense à lire le règlement pour réussir ton oral !
            
            Les Douaniers enveront un message quand ils seront disponible pour ton recrutement ! 
            
            Bonne chance !`)
            .setColor('20ff36')
            .setThumbnail('https://cdn.discordapp.com/attachments/787776418309210114/804451583856214016/image0.jpg')
            .setFooter('WL ACCEPTE .')
            .setTimestamp()
            )
    },
    name: 'wl-accepte'
}