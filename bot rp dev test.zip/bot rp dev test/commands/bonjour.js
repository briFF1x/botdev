module.exports = {
    run: message => message.channel.send('bonjour à toi'),
    name: 'bjr'
}