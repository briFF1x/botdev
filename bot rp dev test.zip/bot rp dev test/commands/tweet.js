const Discord = require('discord.js')
const { name } = require('./kick')
 
module.exports = {
    run: (message, args) => {
      const msgToSend = args.join(' ')
if(!msgToSend) return message.reply(`Veuillez indiquer du texte à envoyer`)
message.delete()
const embed = new Discord.MessageEmbed()
  .setTitle('Tweet')
  .setDescription(`**Nouveau tweet de ${message.author} :**\n\n> ${msgToSend}`)
  .setColor('#009eff')
  .setFooter(`Tweet de ${message.author.username}`)
  .setThumbnail('https://cdn.discordapp.com/attachments/804606544351068191/804707507570212904/image0.jpg')
  .setTimestamp()
 message.channel.send(embed)
},
name: 'tweet'
}