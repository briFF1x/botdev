const Discord = require('discord.js')
const { name } = require('./kick')
 
module.exports = {
    run: (message, args) => {
      const msgToSend = args.join(' ')
      if(!args[0] || !args[1]) return message.reply(`Veuillez entrer l'heure et le pseudonyme du lanceur, exemple :
      !session 17h30 Wazax_BOT`)
message.delete()
const embed = new Discord.MessageEmbed()
  .setTitle('**:bell: | Annonce Session**')
  .setDescription(`*:video_game: | Une session est prévu !
  
  :clock1: | Cette session va commencer à ${args[0]} !
  
  :arrow_right: | Pseudonyme du lanceur de session : ${args[1]}*

  **Votez en fonction de vos disponibilités: 
  :white_check_mark: : Présent
  :negative_squared_cross_mark: : Absent
  :watch: : En retard
  :thinking: : Présence à confirmer**`)
  .setColor('#0075ff')
  .setFooter(`Session de ${message.author.username}`)
  .setThumbnail('https://cdn.discordapp.com/attachments/804606544351068191/804615941337251870/image0.gif')
  .setTimestamp()
 message.channel.send(embed).then(m => {
  m.react(':white_check_mark:')
  m.react(':negative_squared_cross_mark:')
  m.react(':watch:')
  m.react(':thinking:')
})
 
},
name: 'session'
}